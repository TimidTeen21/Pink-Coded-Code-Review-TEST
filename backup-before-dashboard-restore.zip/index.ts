//frontend/app/components/index.ts
export { default as AnalysisResults } from './AnalysisResults'